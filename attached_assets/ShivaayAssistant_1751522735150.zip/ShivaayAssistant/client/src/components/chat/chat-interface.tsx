import { useRef, useEffect } from "react";
import { MessageBubble } from "./message-bubble";
import { TypingIndicator } from "./typing-indicator";
import { type Message, type ConversationMode } from "@shared/schema";

interface ChatInterfaceProps {
  mode: ConversationMode;
  messages: Message[];
  isTyping: boolean;
  onSendMessage: (content: string) => void;
}

export function ChatInterface({ mode, messages, isTyping, onSendMessage }: ChatInterfaceProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputRef.current) return;
    
    const content = inputRef.current.value.trim();
    if (content) {
      onSendMessage(content);
      inputRef.current.value = '';
      inputRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleInputChange = () => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = Math.min(inputRef.current.scrollHeight, 200) + 'px';
    }
  };

  const quickActions = [
    "Solve: x² + 5x + 6 = 0",
    "Write a sorting algorithm in Python",
    "Latest AI news today",
    "Explain quantum computing basics"
  ];

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto scrollbar-hide" style={{ scrollBehavior: 'smooth' }}>
        <div className="max-w-5xl mx-auto p-4 md:p-6">
          {/* Welcome Message */}
          {messages.length === 0 && (
            <div className="text-center py-8 md:py-12">
              <div className="w-16 h-16 md:w-20 md:h-20 gradient-bg rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-brain text-white text-2xl md:text-3xl"></i>
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-white mb-4">Welcome to Shivaay AI!</h1>
              <p className="text-slate-400 text-base md:text-lg mb-6 md:mb-8 max-w-2xl mx-auto px-4">
                I'm your advanced AI assistant. I can help you with reasoning, coding, mathematics, web search, and much more!
              </p>
              
              {/* Capability Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 max-w-4xl mx-auto mb-6 md:mb-8 px-4">
                <div className="shivaay-surface border rounded-xl p-3 md:p-4 hover:border-primary hover:border-opacity-50 transition-colors cursor-pointer">
                  <div className="w-8 h-8 md:w-10 md:h-10 bg-blue-500 rounded-lg flex items-center justify-center mx-auto mb-2 md:mb-3">
                    <i className="fas fa-lightbulb text-white text-sm md:text-base"></i>
                  </div>
                  <h3 className="font-semibold text-white mb-1 text-sm md:text-base">Reasoning & Logic</h3>
                  <p className="text-xs md:text-sm text-slate-400">Complex problem solving</p>
                </div>
                <div className="shivaay-surface border rounded-xl p-3 md:p-4 hover:border-primary hover:border-opacity-50 transition-colors cursor-pointer">
                  <div className="w-8 h-8 md:w-10 md:h-10 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-2 md:mb-3">
                    <i className="fas fa-code text-white text-sm md:text-base"></i>
                  </div>
                  <h3 className="font-semibold text-white mb-1 text-sm md:text-base">Code Generation</h3>
                  <p className="text-xs md:text-sm text-slate-400">Programming assistance</p>
                </div>
                <div className="shivaay-surface border rounded-xl p-3 md:p-4 hover:border-primary hover:border-opacity-50 transition-colors cursor-pointer">
                  <div className="w-8 h-8 md:w-10 md:h-10 bg-yellow-500 rounded-lg flex items-center justify-center mx-auto mb-2 md:mb-3">
                    <i className="fas fa-calculator text-white text-sm md:text-base"></i>
                  </div>
                  <h3 className="font-semibold text-white mb-1 text-sm md:text-base">Mathematics</h3>
                  <p className="text-xs md:text-sm text-slate-400">Advanced calculations</p>
                </div>
                <div className="shivaay-surface border rounded-xl p-3 md:p-4 hover:border-primary hover:border-opacity-50 transition-colors cursor-pointer">
                  <div className="w-8 h-8 md:w-10 md:h-10 bg-purple-500 rounded-lg flex items-center justify-center mx-auto mb-2 md:mb-3">
                    <i className="fas fa-search text-white text-sm md:text-base"></i>
                  </div>
                  <h3 className="font-semibold text-white mb-1 text-sm md:text-base">Web Search</h3>
                  <p className="text-xs md:text-sm text-slate-400">Research assistance</p>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex flex-wrap justify-center gap-2 md:gap-3 px-4">
                {quickActions.map((action, index) => (
                  <button
                    key={index}
                    onClick={() => onSendMessage(action)}
                    className="bg-slate-700 hover:bg-slate-600 text-white px-3 md:px-4 py-2 rounded-xl transition-colors text-xs md:text-sm whitespace-nowrap"
                  >
                    {action}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Chat Messages */}
          <div className="space-y-0">
            {messages.map((message) => (
              <MessageBubble key={message.id} message={message} />
            ))}
            {isTyping && <TypingIndicator />}
            <div ref={messagesEndRef} />
          </div>
        </div>
      </div>

      {/* Input Area */}
      <div className="shivaay-surface border-t p-3 md:p-4">
        <div className="max-w-5xl mx-auto">
          <form onSubmit={handleSubmit} className="flex items-end gap-2 md:gap-3">
            <div className="flex-1">
              <div className="relative">
                <textarea
                  ref={inputRef}
                  rows={1}
                  className="w-full px-3 md:px-4 py-2 md:py-3 pr-10 md:pr-12 shivaay-surface border rounded-2xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none text-sm md:text-base"
                  placeholder="Ask me anything - I'll auto-select the best model..."
                  style={{ minHeight: '44px', maxHeight: '200px' }}
                  onKeyDown={handleKeyDown}
                  onChange={handleInputChange}
                />
                <button
                  type="button"
                  className="absolute right-2 md:right-3 top-1/2 transform -translate-y-1/2 p-1 md:p-2 hover:bg-slate-700 rounded-lg transition-colors"
                >
                  <i className="fas fa-paperclip text-slate-400 text-sm"></i>
                </button>
              </div>
              <div className="flex items-center justify-between mt-1 md:mt-2 px-2 text-xs">
                <div className="flex items-center gap-2 text-slate-500">
                  <i className="fas fa-toggle-on text-green-400"></i>
                  <span className="hidden sm:inline">Mode: {mode}</span>
                  <span className="sm:hidden">Auto AI</span>
                </div>
                <div className="text-slate-500">
                  <span className="hidden md:inline">Shift + Enter for new line</span>
                  <span className="md:hidden">Shift+↵</span>
                </div>
              </div>
            </div>
            <button
              type="submit"
              className="gradient-bg hover:opacity-90 text-white p-2 md:p-3 rounded-2xl transition-all duration-200 flex-shrink-0"
            >
              <i className="fas fa-paper-plane text-sm md:text-base"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
