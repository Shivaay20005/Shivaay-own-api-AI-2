import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

interface ImageGenerationParams {
  prompt: string;
  aspectRatio: string;
  steps: number;
  guidance: number;
  seed: string;
  enhance: boolean;
  safe: boolean;
}

export function ImageGenerator() {
  const [params, setParams] = useState<ImageGenerationParams>({
    prompt: '',
    aspectRatio: '1:1',
    steps: 30,
    guidance: 7.5,
    seed: '',
    enhance: false,
    safe: true,
  });
  
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const generateImageMutation = useMutation({
    mutationFn: async (data: ImageGenerationParams) => {
      const response = await apiRequest('POST', '/api/generate-image', data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedImage(data.imageUrl);
    },
  });

  const handleGenerate = () => {
    if (!params.prompt.trim()) return;
    generateImageMutation.mutate(params);
  };

  const handleDownload = () => {
    if (generatedImage) {
      const link = document.createElement('a');
      link.href = generatedImage;
      link.download = 'shivaay-ai-generated-image.png';
      link.click();
    }
  };

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide">
      <div className="max-w-4xl mx-auto p-6">
        <div className="shivaay-surface border rounded-2xl p-6 mb-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <i className="fas fa-palette text-teal-400"></i>
            Image Generation Studio
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Generation Controls */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="prompt" className="text-slate-300">Prompt</Label>
                <Textarea
                  id="prompt"
                  rows={3}
                  className="shivaay-surface border text-white placeholder-slate-500 focus:ring-teal-500"
                  placeholder="Describe the image you want to generate..."
                  value={params.prompt}
                  onChange={(e) => setParams({ ...params, prompt: e.target.value })}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="aspectRatio" className="text-slate-300">Aspect Ratio</Label>
                  <Select value={params.aspectRatio} onValueChange={(value) => setParams({ ...params, aspectRatio: value })}>
                    <SelectTrigger className="shivaay-surface border text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1:1">Square (1:1)</SelectItem>
                      <SelectItem value="16:9">Landscape (16:9)</SelectItem>
                      <SelectItem value="9:16">Portrait (9:16)</SelectItem>
                      <SelectItem value="4:3">Standard (4:3)</SelectItem>
                      <SelectItem value="3:4">Portrait (3:4)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="steps" className="text-slate-300">Steps</Label>
                  <Input
                    id="steps"
                    type="number"
                    min="1"
                    max="150"
                    className="shivaay-surface border text-white"
                    value={params.steps}
                    onChange={(e) => setParams({ ...params, steps: parseInt(e.target.value) })}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="guidance" className="text-slate-300">Guidance Scale</Label>
                  <Input
                    id="guidance"
                    type="number"
                    min="1"
                    max="20"
                    step="0.1"
                    className="shivaay-surface border text-white"
                    value={params.guidance}
                    onChange={(e) => setParams({ ...params, guidance: parseFloat(e.target.value) })}
                  />
                </div>
                <div>
                  <Label htmlFor="seed" className="text-slate-300">Seed</Label>
                  <Input
                    id="seed"
                    type="text"
                    placeholder="Random"
                    className="shivaay-surface border text-white placeholder-slate-500"
                    value={params.seed}
                    onChange={(e) => setParams({ ...params, seed: e.target.value })}
                  />
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="enhance"
                      checked={params.enhance}
                      onCheckedChange={(checked) => setParams({ ...params, enhance: checked as boolean })}
                    />
                    <Label htmlFor="enhance" className="text-slate-300">Quantum Enhance</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="safe"
                      checked={params.safe}
                      onCheckedChange={(checked) => setParams({ ...params, safe: checked as boolean })}
                    />
                    <Label htmlFor="safe" className="text-slate-300">Safety Protocol</Label>
                  </div>
                </div>
              </div>
              
              <Button
                onClick={handleGenerate}
                disabled={!params.prompt.trim() || generateImageMutation.isPending}
                className="w-full bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600 text-white"
              >
                {generateImageMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Generating...
                  </>
                ) : (
                  <>
                    <i className="fas fa-wand-magic-sparkles mr-2"></i>
                    Generate Image
                  </>
                )}
              </Button>
            </div>
            
            {/* Generated Image Preview */}
            <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 flex items-center justify-center min-h-[300px]">
              {generatedImage ? (
                <div className="w-full">
                  <img 
                    src={generatedImage} 
                    alt="Generated image" 
                    className="w-full h-auto rounded-lg shadow-lg mb-4"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleDownload}
                      className="flex-1 bg-teal-500 hover:bg-teal-600 text-white"
                    >
                      <i className="fas fa-download mr-2"></i>Download
                    </Button>
                    <Button
                      variant="secondary"
                      className="flex-1"
                    >
                      <i className="fas fa-share mr-2"></i>Share
                    </Button>
                  </div>
                </div>
              ) : generateImageMutation.isPending ? (
                <div className="text-center">
                  <div className="animate-spin w-12 h-12 border-4 border-teal-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                  <p className="text-slate-300">Generating image...</p>
                  <p className="text-sm text-slate-500 mt-2">"{params.prompt}"</p>
                </div>
              ) : (
                <div className="text-center text-slate-400">
                  <i className="fas fa-image text-6xl mb-4 opacity-50"></i>
                  <p>Generated image will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
