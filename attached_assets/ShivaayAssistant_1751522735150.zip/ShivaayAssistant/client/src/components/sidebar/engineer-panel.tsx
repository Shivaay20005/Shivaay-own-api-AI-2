import { AI_MODELS } from "@shared/schema";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function EngineerPanel() {
  const [showModelName, setShowModelName] = useState(true);
  const [customModelDisplay, setCustomModelDisplay] = useState("");
  const [useCustomDisplay, setUseCustomDisplay] = useState(false);
  const modelEntries = Object.entries(AI_MODELS).slice(0, 12); // Show first 12 models

  const getIconClass = (icon: string) => {
    const iconMap: Record<string, string> = {
      'microchip': 'fa-microchip',
      'robot': 'fa-robot',
      'moon': 'fa-moon',
      'brain': 'fa-brain',
      'star': 'fa-star',
      'wind': 'fa-wind',
      'google': 'fa-google',
      'cpu': 'fa-microchip',
      'eye': 'fa-eye',
      'question': 'fa-question',
      'code': 'fa-code',
      'flame': 'fa-fire',
      'windows': 'fa-windows',
      'zap': 'fa-bolt',
      'search': 'fa-search',
      'chat': 'fa-comments',
      'feather': 'fa-feather',
      'flash': 'fa-bolt',
      'scroll': 'fa-scroll',
      'dolphin': 'fa-fish',
    };
    return iconMap[icon] || 'fa-brain';
  };

  const getColorClass = (color: string) => {
    const colorMap: Record<string, string> = {
      'emerald': 'bg-emerald-500',
      'blue': 'bg-blue-500',
      'purple': 'bg-purple-500',
      'indigo': 'bg-indigo-500',
      'violet': 'bg-violet-500',
      'orange': 'bg-orange-500',
      'amber': 'bg-amber-500',
      'red': 'bg-red-500',
      'yellow': 'bg-yellow-500',
      'lime': 'bg-lime-500',
      'green': 'bg-green-500',
      'teal': 'bg-teal-500',
      'cyan': 'bg-cyan-500',
      'sky': 'bg-sky-500',
      'slate': 'bg-slate-500',
      'pink': 'bg-pink-500',
    };
    return colorMap[color] || 'bg-purple-500';
  };

  // Store settings in localStorage
  const saveSettings = () => {
    localStorage.setItem('shivaay_model_display', JSON.stringify({
      showModelName,
      customModelDisplay,
      useCustomDisplay
    }));
  };

  const handleShowModelToggle = (checked: boolean) => {
    setShowModelName(checked);
    // Auto-save
    setTimeout(saveSettings, 100);
  };

  const handleCustomDisplayToggle = (checked: boolean) => {
    setUseCustomDisplay(checked);
    setTimeout(saveSettings, 100);
  };

  const handleCustomDisplayChange = (value: string) => {
    setCustomModelDisplay(value);
    setTimeout(saveSettings, 500); // Debounce
  };

  return (
    <div className="mt-6 space-y-4">
      {/* Model Display Controls */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
          <i className="fas fa-display text-blue-400"></i>
          Model Display Settings
        </h3>
        
        <div className="space-y-3">
          {/* Show/Hide Model Name */}
          <div className="flex items-center justify-between">
            <Label htmlFor="show-model" className="text-sm text-slate-300">
              Show Model Name
            </Label>
            <Switch
              id="show-model"
              checked={showModelName}
              onCheckedChange={handleShowModelToggle}
            />
          </div>

          {/* Custom Model Display */}
          <div className="flex items-center justify-between">
            <Label htmlFor="custom-display" className="text-sm text-slate-300">
              Use Custom Display
            </Label>
            <Switch
              id="custom-display" 
              checked={useCustomDisplay}
              onCheckedChange={handleCustomDisplayToggle}
            />
          </div>

          {useCustomDisplay && (
            <div className="space-y-2">
              <Label htmlFor="custom-text" className="text-xs text-slate-400">
                Custom Model Display Text
              </Label>
              <Input
                id="custom-text"
                placeholder="e.g., Shivaay AI Pro, My Assistant..."
                value={customModelDisplay}
                onChange={(e) => handleCustomDisplayChange(e.target.value)}
                className="bg-slate-700 border-slate-600 text-white text-sm"
              />
            </div>
          )}

          <div className="text-xs text-slate-500 bg-slate-900/50 p-2 rounded">
            <strong>Preview:</strong> {
              !showModelName 
                ? "Hidden" 
                : useCustomDisplay && customModelDisplay 
                  ? customModelDisplay 
                  : "Qwen 8B (example)"
            }
          </div>
        </div>
      </div>

      {/* Model List */}
      <div>
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3 flex items-center gap-2">
          <i className="fas fa-cogs text-primary"></i>
          Available Models ({Object.keys(AI_MODELS).length})
        </h3>
          <div className="space-y-2 max-h-96 overflow-y-auto scrollbar-hide">
            {modelEntries.map(([modelId, config]) => (
              <div
                key={modelId}
                className="model-card bg-slate-800 bg-opacity-50 border border-slate-700 rounded-lg p-2 hover:bg-slate-700 transition-all"
              >
                <div className="flex items-center gap-2">
                  <div className={`w-6 h-6 ${getColorClass(config.color)} rounded-md flex items-center justify-center flex-shrink-0`}>
                    <i className={`${getIconClass(config.icon)} text-white text-xs`}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-white text-xs truncate">
                      {config.name}
                    </div>
                    <div className="text-xs text-slate-500 truncate">
                      {modelId.split('/')[1]?.split(':')[0] || modelId}
                    </div>
                  </div>
                  <div className="w-1.5 h-1.5 bg-green-400 rounded-full flex-shrink-0"></div>
                </div>
              </div>
            ))}
            
            {Object.keys(AI_MODELS).length > 12 && (
              <div className="text-center py-2">
                <span className="text-xs text-slate-500">
                  +{Object.keys(AI_MODELS).length - 12} more models available
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
  );
}
