import { useState } from "react";
import { Sidebar } from "@/components/sidebar/sidebar";
import { ChatInterface } from "@/components/chat/chat-interface";
import { ImageGenerator } from "@/components/image/image-generator";
import { PasswordModal } from "@/components/auth/password-modal";
import { AuthModal } from "@/components/auth/auth-modal";
import { useEngineerMode } from "@/hooks/use-engineer-mode";
import { useAuth } from "@/contexts/auth-context";
import { useChat } from "@/hooks/use-chat";
import { Button } from "@/components/ui/button";
import { LogIn, LogOut, User } from "lucide-react";
import { type ConversationMode, type Message } from "@shared/schema";

export default function Home() {
  const [currentMode, setCurrentMode] = useState<ConversationMode>('general');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  const { user, isLoading, signOut } = useAuth();
  const { isEngineerMode, verifyPassword } = useEngineerMode();
  const { 
    messages, 
    isTyping, 
    sendMessage, 
    currentConversation,
    createNewConversation 
  } = useChat(currentMode);

  const handleModeChange = async (mode: ConversationMode) => {
    setCurrentMode(mode);
    // Create new conversation for new mode
    await createNewConversation(mode);
    // Close sidebar on mobile
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  const handlePasswordSubmit = async (password: string) => {
    const success = await verifyPassword(password);
    if (success) {
      setShowPasswordModal(false);
    }
    return success;
  };

  const handleConversationChange = async (conversationId: number) => {
    // Switch to existing conversation
    console.log(`Switching to conversation ${conversationId}`);
    // For now, just close sidebar on mobile
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  const handleNewChat = async () => {
    await createNewConversation(currentMode);
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  const handleAuthSuccess = (authenticatedUser: any) => {
    setShowAuthModal(false);
    window.location.reload();
  };

  const handleSignOut = async () => {
    await signOut();
    window.location.reload();
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Sidebar */}
      <Sidebar
        currentMode={currentMode}
        onModeChange={handleModeChange}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        isEngineerMode={isEngineerMode}
        onShowPasswordModal={() => setShowPasswordModal(true)}
        currentConversationId={currentConversation}
        onConversationChange={handleConversationChange}
        onNewChat={handleNewChat}
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <div className="shivaay-surface border-b p-3 md:p-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 hover:bg-slate-700 rounded-lg transition-colors"
            >
              <i className="fas fa-bars text-slate-400"></i>
            </button>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="w-6 h-6 md:w-8 md:h-8 gradient-bg rounded-lg flex items-center justify-center">
                <i className="fas fa-robot text-white text-xs md:text-sm"></i>
              </div>
              <div className="hidden sm:block">
                <h2 className="font-semibold text-white text-sm md:text-base">Shivaay AI</h2>
                <p className="text-xs md:text-sm text-slate-400">
                  Mode: <span className="capitalize">{currentMode}</span>
                </p>
              </div>
              <div className="sm:hidden">
                <h2 className="font-semibold text-white text-sm">Shivaay AI</h2>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-sm text-slate-400">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>Optimal Performance</span>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        {currentMode === 'image' ? (
          <ImageGenerator />
        ) : (
          <ChatInterface
            mode={currentMode}
            messages={(messages as Message[]) || []}
            isTyping={isTyping}
            onSendMessage={sendMessage}
          />
        )}
      </div>

      {/* Password Modal */}
      <PasswordModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        onSubmit={handlePasswordSubmit}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
