import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { wsService } from "@/lib/websocket";
import { apiRequest } from "@/lib/queryClient";
import { type Message, type ConversationMode } from "@shared/schema";

export function useChat(mode: ConversationMode) {
  const [currentConversation, setCurrentConversation] = useState<number | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const queryClient = useQueryClient();

  // Get messages for current conversation
  const { data: messages = [] } = useQuery({
    queryKey: [`/api/conversations/${currentConversation}/messages`],
    enabled: !!currentConversation,
  });

  // Create new conversation
  const createConversationMutation = useMutation({
    mutationFn: async (mode: ConversationMode) => {
      const response = await apiRequest('POST', '/api/conversations', {
        mode,
        title: `${mode} conversation`
      });
      return response.json();
    },
    onSuccess: (conversation) => {
      setCurrentConversation(conversation.id);
    },
  });

  // Auto-create conversation when mode changes and no conversation exists
  useEffect(() => {
    if (!currentConversation) {
      createConversationMutation.mutate(mode);
    }
  }, [mode]);

  // Initialize WebSocket
  useEffect(() => {
    wsService.connect();
    
    wsService.onMessage('message_saved', (data) => {
      setIsTyping(true); // Start typing when user message is saved
      queryClient.invalidateQueries({
        queryKey: [`/api/conversations/${currentConversation}/messages`]
      });
    });

    wsService.onMessage('ai_response', (data) => {
      setIsTyping(false);
      queryClient.invalidateQueries({
        queryKey: [`/api/conversations/${currentConversation}/messages`]
      });
    });

    wsService.onMessage('error', (data) => {
      setIsTyping(false);
      console.error('Chat error:', data);
    });

    return () => {
      wsService.disconnect();
    };
  }, [currentConversation, queryClient]);

  const sendMessage = (content: string) => {
    console.log('Sending message:', { content, currentConversation, mode });
    
    if (!currentConversation) {
      console.log('No conversation, creating one...');
      createConversationMutation.mutate(mode);
      return;
    }
    
    setIsTyping(true);
    wsService.send('chat', {
      conversationId: currentConversation,
      content,
      mode
    });
  };

  const createNewConversation = async (mode: ConversationMode) => {
    await createConversationMutation.mutateAsync(mode);
  };

  return {
    messages,
    isTyping,
    sendMessage,
    currentConversation,
    createNewConversation,
  };
}
