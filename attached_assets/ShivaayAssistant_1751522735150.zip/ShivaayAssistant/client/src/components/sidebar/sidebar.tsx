import { ModeSelector } from "./mode-selector";
import { EngineerPanel } from "./engineer-panel";
import { type ConversationMode, type Conversation } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { MessageSquare, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  currentMode: ConversationMode;
  onModeChange: (mode: ConversationMode) => void;
  isOpen: boolean;
  onToggle: () => void;
  isEngineerMode: boolean;
  onShowPasswordModal: () => void;
  currentConversationId?: number;
  onConversationChange: (conversationId: number) => void;
  onNewChat: () => void;
}

export function Sidebar({
  currentMode,
  onModeChange,
  isOpen,
  onToggle,
  isEngineerMode,
  onShowPasswordModal,
  currentConversationId,
  onConversationChange,
  onNewChat,
}: SidebarProps) {
  // Fetch conversation history
  const { data: conversations = [] } = useQuery<Conversation[]>({
    queryKey: ['/api/conversations'],
    enabled: isEngineerMode // Only load history in engineer mode
  });

  return (
    <div className={`w-80 shivaay-surface border-r sidebar-transition transform ${
      isOpen ? 'translate-x-0' : '-translate-x-full'
    } lg:translate-x-0 fixed lg:relative z-40 h-full`}>
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="p-6 border-b border-slate-700">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 gradient-bg rounded-xl flex items-center justify-center">
              <i className="fas fa-brain text-white text-lg"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Shivaay AI</h1>
              <p className="text-sm text-slate-400">
                {isEngineerMode ? 'Engineer Mode Active' : 'Local Assistant'}
              </p>
            </div>
          </div>
          
          {/* New Chat Button */}
          <Button 
            onClick={onNewChat}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white mb-4"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Chat
          </Button>
          
          {/* Status Indicator */}
          <div className="flex items-center gap-2 text-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-slate-300">Fully Online</span>
            <span className="text-slate-500">
              • {isEngineerMode ? '48+ Models Active' : 'Auto-Select Mode'}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto scrollbar-hide p-4 space-y-4">
          <ModeSelector
            currentMode={currentMode}
            onModeChange={onModeChange}
          />
          
          {/* Chat History (Engineer Mode Only) */}
          {isEngineerMode && conversations.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-slate-300 px-2">Chat History</h3>
              <div className="space-y-1">
                {conversations.slice(0, 10).map((conversation) => (
                  <button
                    key={conversation.id}
                    onClick={() => onConversationChange(conversation.id)}
                    className={`w-full text-left p-3 rounded-lg transition-colors group ${
                      currentConversationId === conversation.id
                        ? 'bg-blue-600/20 border border-blue-500/30'
                        : 'hover:bg-slate-700/50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-slate-400" />
                      <span className="text-sm text-slate-300 truncate flex-1">
                        {conversation.title || `${conversation.mode} conversation`}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-1 truncate">
                      {conversation.createdAt ? new Date(conversation.createdAt).toLocaleDateString() : 'Recent'}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {isEngineerMode && <EngineerPanel />}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-700">
          <button
            onClick={onShowPasswordModal}
            className="w-full bg-slate-700 hover:bg-slate-600 text-white px-4 py-2 rounded-xl transition-colors text-sm"
          >
            <i className="fas fa-cog mr-2"></i>
            {isEngineerMode ? 'Engineer Mode' : 'Engineer Mode'}
          </button>
        </div>
      </div>
    </div>
  );
}
