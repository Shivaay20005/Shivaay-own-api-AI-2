import { CONVERSATION_MODES, type ConversationMode } from "@shared/schema";

interface ModeSelectorProps {
  currentMode: ConversationMode;
  onModeChange: (mode: ConversationMode) => void;
}

export function ModeSelector({ currentMode, onModeChange }: ModeSelectorProps) {
  const modeColors = {
    general: 'bg-primary bg-opacity-20 border-primary border-opacity-30',
    friend: 'bg-green-500 bg-opacity-20 border-green-500 border-opacity-30',
    girlfriend: 'bg-pink-500 bg-opacity-20 border-pink-500 border-opacity-30',
    shayar: 'bg-purple-500 bg-opacity-20 border-purple-500 border-opacity-30',
    search: 'bg-blue-500 bg-opacity-20 border-blue-500 border-opacity-30',
    coding: 'bg-indigo-500 bg-opacity-20 border-indigo-500 border-opacity-30',
    math: 'bg-orange-500 bg-opacity-20 border-orange-500 border-opacity-30',
    codesearch: 'bg-cyan-500 bg-opacity-20 border-cyan-500 border-opacity-30',
    procoder: 'bg-red-500 bg-opacity-20 border-red-500 border-opacity-30',
    image: 'bg-teal-500 bg-opacity-20 border-teal-500 border-opacity-30',
  };

  const modeIconColors = {
    general: 'bg-primary',
    friend: 'bg-green-500',
    girlfriend: 'bg-pink-500',
    shayar: 'bg-purple-500',
    search: 'bg-blue-500',
    coding: 'bg-indigo-500',
    math: 'bg-orange-500',
    codesearch: 'bg-cyan-500',
    procoder: 'bg-red-500',
    image: 'bg-teal-500',
  };

  return (
    <div className="mb-6">
      <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">
        Conversation Modes
      </h3>
      <div className="space-y-2">
        {Object.entries(CONVERSATION_MODES).map(([key, config]) => {
          const mode = key as ConversationMode;
          const isActive = currentMode === mode;
          
          return (
            <div
              key={mode}
              onClick={() => onModeChange(mode)}
              className={`mode-item rounded-xl p-3 cursor-pointer hover:bg-opacity-30 transition-all ${
                isActive 
                  ? modeColors[mode] 
                  : 'bg-slate-800 bg-opacity-50 border border-slate-700 hover:bg-slate-700'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 ${modeIconColors[mode]} rounded-lg flex items-center justify-center`}>
                  <i className={`fas fa-${config.icon} text-white text-sm`}></i>
                </div>
                <div>
                  <div className="font-medium text-white">{config.title}</div>
                  <div className="text-xs text-slate-400">{config.description}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
