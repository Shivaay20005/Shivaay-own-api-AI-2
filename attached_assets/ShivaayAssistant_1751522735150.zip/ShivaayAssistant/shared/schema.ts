import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").unique(),
  password: text("password"), // Optional for Firebase users
  firebaseUid: text("firebase_uid").unique(), // Firebase user ID
  displayName: text("display_name"),
  photoURL: text("photo_url"),
  provider: text("provider").default("local"), // "local", "firebase", "google"
  createdAt: timestamp("created_at").defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mode: text("mode").notNull(),
  title: text("title"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  metadata: json("metadata"), // model info, tokens, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const generatedImages = pgTable("generated_images", {
  id: serial("id").primaryKey(),
  prompt: text("prompt").notNull(),
  imageUrl: text("image_url").notNull(),
  parameters: json("parameters"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  firebaseUid: true,
  displayName: true,
  photoURL: true,
  provider: true,
});

export const loginUserSchema = z.object({
  email: z.string().email().optional(),
  username: z.string().optional(),
  password: z.string().min(6),
}).refine(data => data.email || data.username, {
  message: "Either email or username is required"
});

export const registerUserSchema = z.object({
  username: z.string().min(3).max(50),
  email: z.string().email(),
  password: z.string().min(6),
  displayName: z.string().optional(),
});

export const firebaseUserSchema = z.object({
  firebaseUid: z.string(),
  email: z.string().email(),
  displayName: z.string().optional(),
  photoURL: z.string().url().optional(),
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  mode: true,
  title: true,
}).extend({
  userId: z.number().optional(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  conversationId: true,
  role: true,
  content: true,
  metadata: true,
});

export const insertImageSchema = createInsertSchema(generatedImages).pick({
  prompt: true,
  imageUrl: true,
  parameters: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type GeneratedImage = typeof generatedImages.$inferSelect;
export type InsertImage = z.infer<typeof insertImageSchema>;

// AI Models Configuration - All Free OpenRouter Models
export const AI_MODELS = {
  // Top Priority Models
  'nvidia/llama-3.3-nemotron-super-49b-v1:free': { name: 'NVIDIA Nemotron Super 49B', icon: 'microchip', color: 'emerald' },
  'meta-llama/llama-4-maverick:free': { name: 'Meta Llama 4 Maverick', icon: 'robot', color: 'blue' },
  'moonshotai/kimi-dev-72b:free': { name: 'Kimi Dev 72B', icon: 'moon', color: 'purple' },
  'deepseek/deepseek-r1-0528-qwen3-8b:free': { name: 'DeepSeek R1 Qwen3 8B', icon: 'brain', color: 'indigo' },
  'deepseek/deepseek-r1-0528:free': { name: 'DeepSeek R1', icon: 'brain', color: 'violet' },
  'sarvamai/sarvam-m:free': { name: 'Sarvam M', icon: 'star', color: 'orange' },
  'mistralai/devstral-small:free': { name: 'Mistral Devstral Small', icon: 'wind', color: 'amber' },
  'google/gemma-3n-e4b-it:free': { name: 'Google Gemma 3N', icon: 'google', color: 'red' },
  
  // Qwen Series
  'qwen/qwen3-30b-a3b:free': { name: 'Qwen3 30B', icon: 'cpu', color: 'yellow' },
  'qwen/qwen3-8b:free': { name: 'Qwen3 8B', icon: 'cpu', color: 'lime' },
  'qwen/qwen3-14b:free': { name: 'Qwen3 14B', icon: 'cpu', color: 'green' },
  'qwen/qwen3-32b:free': { name: 'Qwen3 32B', icon: 'cpu', color: 'teal' },
  'qwen/qwen3-235b-a22b:free': { name: 'Qwen3 235B', icon: 'cpu', color: 'cyan' },
  'qwen/qwen2.5-vl-32b-instruct:free': { name: 'Qwen2.5 VL 32B', icon: 'eye', color: 'sky' },
  'qwen/qwen2.5-vl-72b-instruct:free': { name: 'Qwen2.5 VL 72B', icon: 'eye', color: 'blue' },
  'qwen/qwq-32b:free': { name: 'QwQ 32B', icon: 'question', color: 'slate' },
  'qwen/qwen-2.5-coder-32b-instruct:free': { name: 'Qwen 2.5 Coder 32B', icon: 'code', color: 'indigo' },
  'qwen/qwen-2.5-72b-instruct:free': { name: 'Qwen 2.5 72B', icon: 'cpu', color: 'purple' },
  
  // Advanced Models
  'tngtech/deepseek-r1t-chimera:free': { name: 'DeepSeek R1T Chimera', icon: 'flame', color: 'red' },
  'microsoft/mai-ds-r1:free': { name: 'Microsoft MAI DS R1', icon: 'windows', color: 'blue' },
  'thudm/glm-z1-32b:free': { name: 'GLM Z1 32B', icon: 'zap', color: 'yellow' },
  'agentica-org/deepcoder-14b-preview:free': { name: 'DeepCoder 14B', icon: 'code', color: 'emerald' },
  'moonshotai/kimi-vl-a3b-thinking:free': { name: 'Kimi VL Thinking', icon: 'brain', color: 'purple' },
  'nvidia/llama-3.1-nemotron-ultra-253b-v1:free': { name: 'NVIDIA Nemotron Ultra 253B', icon: 'microchip', color: 'green' },
  'meta-llama/llama-4-scout:free': { name: 'Meta Llama 4 Scout', icon: 'search', color: 'blue' },
  
  // DeepSeek Series
  'deepseek/deepseek-v3-base:free': { name: 'DeepSeek V3 Base', icon: 'brain', color: 'indigo' },
  'deepseek/deepseek-chat-v3-0324:free': { name: 'DeepSeek Chat V3', icon: 'chat', color: 'purple' },
  'deepseek/deepseek-r1-distill-qwen-14b:free': { name: 'DeepSeek R1 Distill Qwen 14B', icon: 'brain', color: 'violet' },
  'deepseek/deepseek-r1-distill-llama-70b:free': { name: 'DeepSeek R1 Distill Llama 70B', icon: 'brain', color: 'indigo' },
  'deepseek/deepseek-r1:free': { name: 'DeepSeek R1', icon: 'brain', color: 'purple' },
  'deepseek/deepseek-chat:free': { name: 'DeepSeek Chat', icon: 'chat', color: 'violet' },
  
  // Google & Mistral Series
  'google/gemini-2.0-flash-exp:free': { name: 'Gemini 2.0 Flash Exp', icon: 'google', color: 'red' },
  'google/gemma-3-4b-it:free': { name: 'Gemma 3 4B', icon: 'google', color: 'orange' },
  'google/gemma-3-12b-it:free': { name: 'Gemma 3 12B', icon: 'google', color: 'yellow' },
  'google/gemma-3-27b-it:free': { name: 'Gemma 3 27B', icon: 'google', color: 'lime' },
  'google/gemma-2-9b-it:free': { name: 'Gemma 2 9B', icon: 'google', color: 'green' },
  'mistralai/mistral-small-3.1-24b-instruct:free': { name: 'Mistral Small 3.1 24B', icon: 'wind', color: 'amber' },
  'mistralai/mistral-small-24b-instruct-2501:free': { name: 'Mistral Small 24B 2501', icon: 'wind', color: 'orange' },
  'mistralai/mistral-nemo:free': { name: 'Mistral Nemo', icon: 'wind', color: 'yellow' },
  'mistralai/mistral-7b-instruct:free': { name: 'Mistral 7B', icon: 'wind', color: 'amber' },
  
  // Meta Llama Series
  'meta-llama/llama-3.3-70b-instruct:free': { name: 'Llama 3.3 70B', icon: 'robot', color: 'blue' },
  'meta-llama/llama-3.2-1b-instruct:free': { name: 'Llama 3.2 1B', icon: 'robot', color: 'cyan' },
  'meta-llama/llama-3.2-11b-vision-instruct:free': { name: 'Llama 3.2 11B Vision', icon: 'eye', color: 'sky' },
  'meta-llama/llama-3.1-8b-instruct:free': { name: 'Llama 3.1 8B', icon: 'robot', color: 'blue' },
  
  // Specialized Models
  'featherless/qwerky-72b:free': { name: 'Qwerky 72B', icon: 'feather', color: 'pink' },
  'rekaai/reka-flash-3:free': { name: 'Reka Flash 3', icon: 'flash', color: 'yellow' },
  'nousresearch/deephermes-3-llama-3-8b-preview:free': { name: 'DeepHermes 3 Llama 8B', icon: 'scroll', color: 'purple' },
  'cognitivecomputations/dolphin3.0-r1-mistral-24b:free': { name: 'Dolphin 3.0 R1 Mistral 24B', icon: 'dolphin', color: 'teal' },
  'cognitivecomputations/dolphin3.0-mistral-24b:free': { name: 'Dolphin 3.0 Mistral 24B', icon: 'dolphin', color: 'cyan' },
} as const;

export type AIModel = keyof typeof AI_MODELS;

export const CONVERSATION_MODES = {
  general: { title: 'Shivaay AI', icon: 'robot', description: 'General assistant mode' },
  friend: { title: 'Friend Talk', icon: 'users', description: 'Casual conversations' },
  girlfriend: { title: 'Girlfriend Mode', icon: 'heart', description: 'Romantic companion' },
  shayar: { title: 'Shayar Mode', icon: 'feather', description: 'Poetry & creativity' },
  search: { title: 'Deep Search', icon: 'search', description: 'Advanced research' },
  coding: { title: 'Deep Coding', icon: 'code', description: 'Programming help' },
  math: { title: 'Mathematics', icon: 'calculator', description: 'Problem solving' },
  codesearch: { title: 'Code Search', icon: 'search-code', description: 'Programming queries' },
  procoder: { title: 'ShivaayPro Coder', icon: 'terminal', description: 'Ultimate debugging' },
  image: { title: 'Image Generation', icon: 'image', description: 'AI art creation' },
} as const;

export type ConversationMode = keyof typeof CONVERSATION_MODES;
