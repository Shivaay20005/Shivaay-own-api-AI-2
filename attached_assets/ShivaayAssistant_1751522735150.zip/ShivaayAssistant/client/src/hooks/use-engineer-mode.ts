import { useState } from "react";
import { AIService } from "@/lib/ai-service";

export function useEngineerMode() {
  const [isEngineerMode, setIsEngineerMode] = useState(false);
  const [availableModels, setAvailableModels] = useState(null);

  const verifyPassword = async (password: string): Promise<boolean> => {
    try {
      const result = await AIService.verifyEngineerPassword(password);
      if (result.valid) {
        setIsEngineerMode(true);
        setAvailableModels(result.models);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Password verification failed:', error);
      return false;
    }
  };

  const exitEngineerMode = () => {
    setIsEngineerMode(false);
    setAvailableModels(null);
  };

  return {
    isEngineerMode,
    availableModels,
    verifyPassword,
    exitEngineerMode,
  };
}
