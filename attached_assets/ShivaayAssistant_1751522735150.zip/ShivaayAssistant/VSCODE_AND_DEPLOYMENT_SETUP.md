# VS Code Development & Production Deployment Guide

## 🚀 Running in VS Code Locally

### Prerequisites
1. **Node.js 18+** - Download from [nodejs.org](https://nodejs.org/)
2. **PostgreSQL** - Install locally or use cloud database
3. **Git** - For version control
4. **VS Code** - With recommended extensions

### Step 1: Clone and Setup
```bash
# Clone your repository
git clone <your-repo-url>
cd shivaay-ai

# Install dependencies
npm install

# Copy environment template
cp .env.example .env
```

### Step 2: Environment Variables (.env)
Create `.env` file in root directory:
```env
# Database (Required)
DATABASE_URL="postgresql://username:password@localhost:5432/shivaay_ai"

# OpenRouter API (Required)
OPENROUTER_API_KEY="your_openrouter_api_key_here"

# Firebase (Optional - for authentication)
VITE_FIREBASE_API_KEY="your_firebase_api_key"
VITE_FIREBASE_PROJECT_ID="your_firebase_project_id"
VITE_FIREBASE_APP_ID="your_firebase_app_id"
VITE_FIREBASE_MESSAGING_SENDER_ID="your_firebase_sender_id"

# Development
NODE_ENV="development"
```

### Step 3: Database Setup
```bash
# Install PostgreSQL locally or use cloud service like Neon, Supabase, or Railway

# For local PostgreSQL:
# 1. Install PostgreSQL
# 2. Create database
createdb shivaay_ai

# 3. Update DATABASE_URL in .env
DATABASE_URL="postgresql://your_username:your_password@localhost:5432/shivaay_ai"

# 4. Push database schema
npm run db:push
```

### Step 4: VS Code Configuration

#### Recommended Extensions (.vscode/extensions.json):
```json
{
  "recommendations": [
    "esbenp.prettier-vscode",
    "bradlc.vscode-tailwindcss",
    "ms-vscode.vscode-typescript-next",
    "formulahendry.auto-rename-tag",
    "christian-kohler.path-intellisense",
    "ms-vscode.vscode-json"
  ]
}
```

#### VS Code Settings (.vscode/settings.json):
```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "typescript.preferences.includePackageJsonAutoImports": "auto",
  "tailwindCSS.experimental.classRegex": [
    ["cn\\(([^)]*)\\)", "'([^']*)'"],
    ["cva\\(([^)]*)\\)", "[\"'`]([^\"'`]*).*?[\"'`]"]
  ]
}
```

### Step 5: Start Development
```bash
# Start development server
npm run dev

# Server will run on:
# Frontend: http://localhost:5173
# Backend: http://localhost:5000
```

---

## 🌐 Production Deployment

### Option 1: Vercel (Recommended for Frontend + Serverless)

#### Changes needed for Vercel:

**1. Update package.json scripts:**
```json
{
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "npm run build:client && npm run build:server",
    "build:client": "vite build",
    "build:server": "esbuild server/index.ts --bundle --platform=node --target=node18 --outfile=dist/server.js --external:pg-native",
    "start": "node dist/server.js",
    "preview": "vite preview"
  }
}
```

**2. Create vercel.json:**
```json
{
  "version": 2,
  "builds": [
    {
      "src": "dist/server.js",
      "use": "@vercel/node"
    },
    {
      "src": "dist/public/**",
      "use": "@vercel/static"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "/dist/server.js"
    },
    {
      "src": "/(.*)",
      "dest": "/dist/public/$1"
    }
  ],
  "env": {
    "DATABASE_URL": "@database_url",
    "OPENROUTER_API_KEY": "@openrouter_api_key",
    "VITE_FIREBASE_API_KEY": "@vite_firebase_api_key",
    "VITE_FIREBASE_PROJECT_ID": "@vite_firebase_project_id",
    "VITE_FIREBASE_APP_ID": "@vite_firebase_app_id"
  }
}
```

**3. Deploy Commands:**
```bash
# Install Vercel CLI
npm i -g vercel

# Login and deploy
vercel login
vercel

# Add environment variables in Vercel dashboard
```

### Option 2: Heroku

#### Changes needed for Heroku:

**1. Create Procfile:**
```
web: npm start
```

**2. Update package.json:**
```json
{
  "engines": {
    "node": "18.x",
    "npm": "9.x"
  },
  "scripts": {
    "heroku-postbuild": "npm run build"
  }
}
```

**3. Deploy Commands:**
```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create app
heroku create your-app-name

# Add PostgreSQL addon
heroku addons:create heroku-postgresql:mini

# Set environment variables
heroku config:set OPENROUTER_API_KEY="your_key"
heroku config:set VITE_FIREBASE_API_KEY="your_key"
heroku config:set NODE_ENV="production"

# Deploy
git push heroku main

# Run migrations
heroku run npm run db:push
```

### Option 3: Railway

#### Changes needed for Railway:

**1. Create railway.json:**
```json
{
  "build": {
    "builder": "nixpacks"
  },
  "deploy": {
    "startCommand": "npm start",
    "healthcheckPath": "/",
    "healthcheckTimeout": 100,
    "restartPolicyType": "never"
  }
}
```

**2. Deploy Commands:**
```bash
# Install Railway CLI
npm i -g @railway/cli

# Login and deploy
railway login
railway init
railway up

# Add PostgreSQL
railway add postgresql

# Set environment variables in Railway dashboard
```

### Option 4: Render

#### Changes needed for Render:

**1. Create render.yaml:**
```yaml
services:
  - type: web
    name: shivaay-ai
    env: node
    buildCommand: npm run build
    startCommand: npm start
    envVars:
      - key: DATABASE_URL
        fromDatabase:
          name: shivaay-ai-db
          property: connectionString
      - key: OPENROUTER_API_KEY
        sync: false
      - key: NODE_ENV
        value: production

databases:
  - name: shivaay-ai-db
    databaseName: shivaay_ai
    user: shivaay
```

---

## 🔧 Code Changes for Different Environments

### 1. Server Configuration (server/index.ts)
```typescript
// CHANGE THIS:
const port = 5000;

// TO THIS:
const port = process.env.PORT || 5000;

// CHANGE THIS:
app.use(express.static("dist/public"));

// TO THIS (for production):
if (process.env.NODE_ENV === 'production') {
  app.use(express.static("dist/public"));
}
```

### 2. Database Configuration (server/db.ts)
```typescript
// ADD SSL configuration for production:
import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set");
}

// ADD THIS for production SSL:
const connectionString = process.env.DATABASE_URL;
const ssl = process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false;

export const pool = new Pool({ 
  connectionString,
  ssl 
});
export const db = drizzle({ client: pool, schema });
```

### 3. CORS Configuration (server/index.ts)
```typescript
// ADD CORS for production:
import cors from 'cors';

// ADD THIS:
const allowedOrigins = process.env.NODE_ENV === 'production' 
  ? ['https://your-domain.com', 'https://your-app.vercel.app']
  : ['http://localhost:5173', 'http://localhost:3000'];

app.use(cors({
  origin: allowedOrigins,
  credentials: true
}));
```

### 4. WebSocket Configuration (server/routes.ts)
```typescript
// UPDATE WebSocket for production:
const wss = new WebSocketServer({ 
  server: httpServer, 
  path: '/ws',
  // ADD THIS for production:
  perMessageDeflate: false
});
```

---

## 📱 Environment-Specific Features

### Development Mode Features:
- Hot reload with Vite
- Detailed error messages
- Development CORS settings
- Local database

### Production Mode Features:
- Optimized builds
- Compressed assets
- Production CORS
- SSL database connections
- Error logging
- Performance monitoring

---

## 🛡️ Security Considerations

### 1. Environment Variables
- Never commit `.env` files
- Use different API keys for dev/prod
- Rotate keys regularly

### 2. Database Security
- Use SSL in production
- Regular backups
- Limited user permissions

### 3. CORS Configuration
- Restrict origins in production
- Validate all inputs
- Rate limiting

---

## 🔍 Troubleshooting

### Common Issues:

**1. Database Connection Errors:**
```bash
# Check DATABASE_URL format
# For local: postgresql://user:pass@localhost:5432/dbname
# For cloud: Use provided connection string
```

**2. Build Failures:**
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

**3. Port Conflicts:**
```bash
# Kill processes on port
npx kill-port 5000
npx kill-port 5173
```

**4. Environment Variables Not Loading:**
```bash
# Make sure .env is in root directory
# Check variable names (VITE_ prefix for frontend)
# Restart development server
```

---

## 📋 Deployment Checklist

### Before Deployment:
- [ ] Test locally with production build (`npm run build && npm start`)
- [ ] Set up production database
- [ ] Configure environment variables
- [ ] Update CORS origins
- [ ] Test all authentication flows
- [ ] Verify API endpoints work
- [ ] Check error handling

### After Deployment:
- [ ] Test all features
- [ ] Monitor error logs
- [ ] Set up monitoring/alerts
- [ ] Configure custom domain (if needed)
- [ ] Set up backups
- [ ] Document deployment process

---

## 🚀 Quick Deploy Commands

### For Vercel:
```bash
npm run build
vercel --prod
```

### For Heroku:
```bash
git push heroku main
```

### For Railway:
```bash
railway up
```

### For Render:
Connect GitHub repository in Render dashboard.

---

**Note:** Remember to update Firebase authorized domains after deployment with your production URL!