import { apiRequest } from "./queryClient";

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  metadata?: any;
}

export interface AIResponse {
  content: string;
  model: string;
  tokens: number;
}

export class AIService {
  static async sendMessage(
    conversationId: number,
    content: string,
    mode: string
  ): Promise<AIResponse> {
    const response = await apiRequest('POST', '/api/chat', {
      conversationId,
      content,
      mode
    });
    return response.json();
  }

  static async generateImage(params: {
    prompt: string;
    aspectRatio: string;
    steps: number;
    guidance: number;
    seed: string;
    enhance: boolean;
    safe: boolean;
  }) {
    const response = await apiRequest('POST', '/api/generate-image', params);
    return response.json();
  }

  static async verifyEngineerPassword(password: string) {
    const response = await apiRequest('POST', '/api/verify-password', { password });
    return response.json();
  }
}
