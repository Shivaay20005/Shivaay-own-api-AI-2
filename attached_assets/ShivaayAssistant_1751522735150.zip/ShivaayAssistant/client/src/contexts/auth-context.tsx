import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { FirebaseAuth } from "@/lib/firebase";
import { User } from "firebase/auth";

interface AuthUser {
  id: number;
  username: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  provider: string | null;
  firebaseUid?: string | null;
}

interface AuthContextType {
  user: AuthUser | null;
  firebaseUser: User | null;
  isLoading: boolean;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshUser = async () => {
    const currentFirebaseUser = FirebaseAuth.getCurrentUser();
    if (currentFirebaseUser) {
      try {
        // Sync with our database
        await FirebaseAuth.syncUserToDatabase(currentFirebaseUser);
      } catch (error) {
        console.error("Error refreshing user:", error);
      }
    }
  };

  const signOut = async () => {
    try {
      await FirebaseAuth.signOut();
      setUser(null);
      setFirebaseUser(null);
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };

  useEffect(() => {
    // Temporarily set a default user for testing
    setUser({
      id: 1,
      username: "guest_user",
      email: "guest@shivaay.ai",
      displayName: "Guest User",
      photoURL: null,
      provider: "local",
      firebaseUid: null
    });
    setIsLoading(false);
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      firebaseUser,
      isLoading,
      signOut,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}