# Firebase Authentication Setup Instructions

## Firebase Console Setup (Required)

### Step 1: Create Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project" or "Add project"
3. Enter project name (e.g., "shivaay-ai-chat")
4. Enable Google Analytics (optional)
5. Click "Create project"

### Step 2: Add Web App
1. In your Firebase project dashboard, click "Add app" button
2. Select the Web platform (</> icon)
3. Enter app nickname (e.g., "Shivaay AI Web")
4. Enable "Firebase Hosting" if you want (optional)
5. Click "Register app"

### Step 3: Get Configuration Keys
After registering the app, you'll see a configuration object like this:
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyB...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef..."
};
```

**Copy these values - you'll need them as environment variables.**

### Step 4: Enable Authentication
1. In the Firebase Console, go to "Authentication" from the left sidebar
2. Click "Get started" if it's your first time
3. Go to "Sign-in method" tab
4. Enable the following providers:

#### Email/Password:
- Click "Email/Password"
- Toggle "Enable"
- Click "Save"

#### Google Sign-in:
- Click "Google"
- Toggle "Enable"
- Select project support email
- Click "Save"

### Step 5: Configure Authorized Domains
1. In Authentication > Settings > Authorized domains
2. Add your development URL: `your-repl-name.replit.dev`
3. Add localhost for local development: `localhost`
4. For production, add your deployed domain

## Environment Variables Setup

You need to add these secrets to your Replit project:

1. `VITE_FIREBASE_API_KEY` - Your Firebase API key
2. `VITE_FIREBASE_PROJECT_ID` - Your Firebase project ID  
3. `VITE_FIREBASE_APP_ID` - Your Firebase app ID
4. `VITE_FIREBASE_MESSAGING_SENDER_ID` - Your Firebase messaging sender ID

### How to Add Secrets in Replit:
1. Open your Repl
2. Click on "Secrets" tab in the left sidebar (lock icon)
3. Add each environment variable with its value from Firebase config

## Testing Firebase Integration

After setup, you can test:
1. Visit your app
2. Try creating an account with email/password
3. Try signing in with Google
4. Check if user data appears in your database

## Firebase Security Rules (Optional but Recommended)

In Firebase Console > Firestore Database > Rules, you can set:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Common Issues & Solutions

### Issue: "Firebase config not found"
- Make sure all VITE_ environment variables are set
- Restart your Repl after adding secrets

### Issue: "Auth domain not authorized"
- Add your Repl URL to authorized domains in Firebase Console
- Format: `your-repl-name.replit.dev`

### Issue: "Google sign-in not working"
- Make sure Google provider is enabled in Firebase Console
- Check if authorized domains are configured

## Production Deployment Notes

When deploying to production:
1. Add production domain to Firebase authorized domains
2. Update environment variables for production
3. Consider enabling additional security features in Firebase Console

---

## Implementation Status

✅ Firebase configuration file created (`client/src/lib/firebase.ts`)
✅ Authentication methods implemented (Email/Password, Google)
✅ Database sync functionality added
✅ User management system ready

**Next**: Add the environment variables from your Firebase project to get authentication working!