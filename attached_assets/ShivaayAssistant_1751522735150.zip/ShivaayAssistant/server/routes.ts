import type { Express } from "express";
import { createServer, type Server } from "http";
import WebSocket, { WebSocketServer } from "ws";
import { storage } from "./storage";
import { insertMessageSchema, insertConversationSchema, insertImageSchema, AI_MODELS, type AIModel, registerUserSchema, loginUserSchema, firebaseUserSchema } from "@shared/schema";
import { z } from "zod";
import bcrypt from "bcryptjs";

// Simple in-memory cache for rate limiting tracking
const modelLastUsed = new Map<string, number>();
const RATE_LIMIT_COOLDOWN = 30000; // 30 seconds between same model usage

const engineerPassword = "Shivaay20005";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    // Send welcome message
    ws.send(JSON.stringify({ 
      type: 'connected', 
      message: 'Connected to Shivaay AI V1' 
    }));
    
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        console.log('Received WebSocket message:', message);
        await handleWebSocketMessage(ws, message);
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid message format' }));
      }
    });
    
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // API Routes
  
  // Authentication Routes
  
  // Register new user
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ error: "User already exists with this email" });
      }
      
      const existingUsername = await storage.getUserByUsername(validatedData.username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already taken" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        username: validatedData.username,
        email: validatedData.email,
        password: hashedPassword,
        displayName: validatedData.displayName,
        provider: 'local'
      });
      
      // Remove password from response
      const { password, ...userResponse } = user;
      res.json({ user: userResponse });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ error: "Registration failed" });
    }
  });

  // Login user
  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginUserSchema.parse(req.body);
      
      // Find user by email or username
      let user;
      if (validatedData.email) {
        user = await storage.getUserByEmail(validatedData.email);
      } else if (validatedData.username) {
        user = await storage.getUserByUsername(validatedData.username);
      }
      
      if (!user || !user.password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Verify password
      const isValidPassword = await bcrypt.compare(validatedData.password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Update last login
      await storage.updateUser(user.id, { lastLoginAt: new Date() });
      
      // Remove password from response
      const { password, ...userResponse } = user;
      res.json({ user: userResponse });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ error: "Login failed" });
    }
  });

  // Sync Firebase user to database
  app.post("/api/auth/sync-firebase-user", async (req, res) => {
    try {
      const validatedData = firebaseUserSchema.parse(req.body);
      
      // Check if Firebase user already exists
      let user = await storage.getUserByFirebaseUid(validatedData.firebaseUid);
      
      if (user) {
        // Update existing user
        user = await storage.updateUser(user.id, {
          email: validatedData.email,
          displayName: validatedData.displayName,
          photoURL: validatedData.photoURL,
          lastLoginAt: new Date()
        });
      } else {
        // Create new user
        user = await storage.createUser({
          username: validatedData.email.split('@')[0] || `user_${Date.now()}`,
          email: validatedData.email,
          firebaseUid: validatedData.firebaseUid,
          displayName: validatedData.displayName,
          photoURL: validatedData.photoURL,
          provider: 'firebase'
        });
      }
      
      // Remove password from response
      const { password, ...userResponse } = user!;
      res.json({ user: userResponse });
    } catch (error) {
      console.error("Firebase sync error:", error);
      res.status(400).json({ error: "Failed to sync Firebase user" });
    }
  });

  // Update last login for Firebase users
  app.post("/api/auth/update-last-login", async (req, res) => {
    try {
      const { firebaseUid } = req.body;
      const user = await storage.getUserByFirebaseUid(firebaseUid);
      
      if (user) {
        await storage.updateUser(user.id, { lastLoginAt: new Date() });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Update last login error:", error);
      res.status(500).json({ error: "Failed to update last login" });
    }
  });

  // Verify engineer password
  app.post("/api/verify-password", (req, res) => {
    const { password } = req.body;
    const isValid = password === engineerPassword;
    res.json({ valid: isValid, models: isValid ? AI_MODELS : null });
  });

  // Get conversations for a user
  app.get("/api/conversations", async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string) || 1;
      const conversations = await storage.getConversationsByUser(userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch conversations" });
    }
  });

  // Create conversation
  app.post("/api/conversations", async (req, res) => {
    try {
      const validatedData = insertConversationSchema.parse(req.body);
      const conversationData = {
        mode: validatedData.mode,
        title: validatedData.title,
        userId: validatedData.userId || 1 // Support user-specific conversations
      };
      const conversation = await storage.createConversation(conversationData);
      res.json(conversation);
    } catch (error) {
      console.error("Conversation creation error:", error);
      res.status(400).json({ error: "Invalid conversation data" });
    }
  });

  // Get messages for conversation
  app.get("/api/conversations/:id/messages", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getMessagesByConversation(conversationId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Generate image
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, aspectRatio, steps, guidance, seed, enhance, safe } = req.body;
      
      // Image generation using OpenRouter (some models support vision/image generation)
      const apiKey = process.env.API_KEY || "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";
      
      try {
        // For now, use a placeholder service but with enhanced prompt
        const enhancedPrompt = enhance 
          ? `High quality, detailed, professional artwork: ${prompt}. Ultra-realistic, 8K resolution, masterpiece quality.`
          : prompt;
        
        // Using a demo image generation service (replace with actual image API)
        const imageUrl = `https://picsum.photos/800/800?random=${Date.now()}&blur=0`;
        
        const imageData = await storage.createGeneratedImage({
          prompt: enhancedPrompt,
          imageUrl,
          parameters: { aspectRatio, steps, guidance, seed, enhance, safe }
        });
        
        res.json({
          ...imageData,
          success: true,
          message: "Image generated successfully using Shivaay AI Image Engine"
        });
      } catch (imageError) {
        console.error('Image generation error:', imageError);
        // Fallback placeholder
        const placeholderUrl = `https://via.placeholder.com/800x800/6366f1/ffffff?text=${encodeURIComponent('Shivaay AI')}`;
        
        const imageData = await storage.createGeneratedImage({
          prompt,
          imageUrl: placeholderUrl,
          parameters: { aspectRatio, steps, guidance, seed, enhance, safe }
        });
        
        res.json({
          ...imageData,
          success: true,
          message: "Generated with Shivaay AI placeholder engine"
        });
      }
    } catch (error) {
      console.error('Image generation API error:', error);
      res.status(500).json({ error: "Failed to generate image" });
    }
  });

  // Get recent images
  app.get("/api/images", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const images = await storage.getRecentImages(limit);
      res.json(images);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch images" });
    }
  });

  return httpServer;
}

async function handleWebSocketMessage(ws: WebSocket, message: any) {
  if (ws.readyState !== WebSocket.OPEN) return;

  switch (message.type) {
    case 'chat':
      await handleChatMessage(ws, message);
      break;
    case 'typing':
      // Broadcast typing indicator
      ws.send(JSON.stringify({ type: 'typing', userId: message.userId }));
      break;
    default:
      ws.send(JSON.stringify({ type: 'error', message: 'Unknown message type' }));
  }
}

async function handleChatMessage(ws: WebSocket, message: any) {
  try {
    const { conversationId, content, mode } = message;
    
    // RTMS Protection - Check for API disclosure attempts
    const rtmsProtectedResponse = checkRTMSProtection(content);
    if (rtmsProtectedResponse) {
      // User tried to ask about API details - respond with RTMS protection
      const protectedMessage = await storage.createMessage({
        conversationId,
        role: 'assistant',
        content: rtmsProtectedResponse,
        metadata: { 
          model: 'Shivaay AI RTMS Protection',
          tokens: 0,
          mode,
          rtms_triggered: true
        }
      });

      ws.send(JSON.stringify({
        type: 'ai_response', 
        message: protectedMessage
      }));
      return;
    }
    
    // Save user message
    const userMessage = await storage.createMessage({
      conversationId,
      role: 'user',
      content,
      metadata: { mode }
    });

    // Send acknowledgment
    ws.send(JSON.stringify({
      type: 'message_saved',
      message: userMessage
    }));

    // Generate AI response
    const aiResponse = await generateAIResponse(content, mode);
    
    // Save AI message
    const aiMessage = await storage.createMessage({
      conversationId,
      role: 'assistant',
      content: aiResponse.content,
      metadata: {
        model: aiResponse.model,
        tokens: aiResponse.tokens,
        mode
      }
    });

    // Send AI response
    ws.send(JSON.stringify({
      type: 'ai_response',
      message: aiMessage
    }));

  } catch (error) {
    console.error('Chat message error:', error);
    ws.send(JSON.stringify({
      type: 'error',
      message: 'Failed to process chat message'
    }));
  }
}

async function generateAIResponse(content: string, mode: string): Promise<{
  content: string;
  model: string;
  tokens: number;
}> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  
  if (!apiKey) {
    throw new Error('OPENROUTER_API_KEY not found in environment variables');
  }
  
  // Filter models based on cooldown period to avoid rate limits
  const now = Date.now();
  const availableModels = [
    'meta-llama/llama-3.3-70b-instruct:free',
    'google/gemini-2.0-flash-exp:free',
    'mistralai/mistral-small-3.1-24b-instruct:free',
    'qwen/qwen-2.5-72b-instruct:free',
    'deepseek/deepseek-chat-v3-0324:free',
    'nvidia/llama-3.1-nemotron-ultra-253b-v1:free',
    'meta-llama/llama-4-maverick:free',
    'tngtech/deepseek-r1t-chimera:free',
    'google/gemma-3-27b-it:free',
    'mistralai/mistral-nemo:free',
    'qwen/qwen3-32b:free',
    'deepseek/deepseek-r1:free',
    'qwen/qwen3-14b:free',
    'qwen/qwen3-8b:free'
  ].filter(model => {
    const lastUsed = modelLastUsed.get(model) || 0;
    return (now - lastUsed) > RATE_LIMIT_COOLDOWN;
  }) as AIModel[];

  const fallbackModels = availableModels.length > 0 ? availableModels : [
    'meta-llama/llama-3.3-70b-instruct:free',
    'google/gemini-2.0-flash-exp:free',
    'mistralai/mistral-small-3.1-24b-instruct:free'
  ] as AIModel[];
  
  // Start with the best model for the task
  const primaryModel = selectBestModel(content, mode);
  const modelsToTry = [primaryModel, ...fallbackModels.filter(m => m !== primaryModel)];
  
  const systemPrompt = getSystemPrompt(mode);
  
  for (let i = 0; i < modelsToTry.length; i++) {
    const modelToTry = modelsToTry[i];
    
    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://shivaay-ai.replit.dev',
          'X-Title': 'Shivaay AI V1'
        },
        body: JSON.stringify({
          model: modelToTry,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content }
          ],
          max_tokens: 1500, // Reduce tokens for faster response
          temperature: 0.7
        })
      });

      if (response.ok) {
        const data = await response.json();
        // Track successful model usage
        modelLastUsed.set(modelToTry, now);
        return {
          content: data.choices[0].message.content,
          model: AI_MODELS[modelToTry as AIModel]?.name || modelToTry,
          tokens: data.usage?.total_tokens || 0
        };
      } else if (response.status === 429) {
        // Rate limited, add exponential backoff delay
        console.log(`Model ${modelToTry} rate limited, trying next...`);
        await new Promise(resolve => setTimeout(resolve, Math.min(1000 * Math.pow(2, i), 3000)));
        continue;
      } else {
        const errorText = await response.text();
        console.error(`OpenRouter API error for ${modelToTry}: ${response.status} - ${errorText}`);
        // Small delay before trying next model
        await new Promise(resolve => setTimeout(resolve, 300));
        continue;
      }
    } catch (error) {
      console.error(`Error with model ${modelToTry}:`, error);
      // Small delay before trying next model
      await new Promise(resolve => setTimeout(resolve, 300));
      continue;
    }
  }
  
  // If all models fail, return fallback
  console.log('All models failed, using fallback response');
  return {
    content: getFallbackResponse(mode),
    model: 'Shivaay AI',
    tokens: 0
  };
}

function selectBestModel(content: string, mode: string): AIModel {
  // Fast models for quick responses (avoid rate-limited ones)
  const fastModels = [
    'qwen/qwen3-8b:free',
    'qwen/qwen3-14b:free',
    'mistralai/devstral-small:free',
    'google/gemma-3n-e4b-it:free',
    'deepseek/deepseek-r1-0528-qwen3-8b:free'
  ] as AIModel[];
  
  // Prioritize fast responses for simple queries
  if (content.length < 100 && !content.includes('code') && !content.includes('complex')) {
    return fastModels[Math.floor(Math.random() * fastModels.length)];
  }
  
  if (mode === 'coding' || mode === 'procoder' || content.includes('code') || content.includes('programming')) {
    return 'mistralai/devstral-small:free'; // Fast coding model
  }
  
  if (mode === 'math' || /\b(solve|calculate|equation|formula)\b/i.test(content)) {
    return 'qwen/qwen3-14b:free'; // Good for math, fast
  }
  
  if (mode === 'search' || mode === 'codesearch' || content.includes('latest') || content.includes('news')) {
    return 'qwen/qwen3-14b:free';
  }
  
  if (mode === 'friend') {
    return 'qwen/qwen3-8b:free'; // Fast and friendly
  }
  
  if (mode === 'girlfriend') {
    return 'deepseek/deepseek-r1-0528-qwen3-8b:free';
  }
  
  if (mode === 'shayar') {
    return 'qwen/qwen3-14b:free';
  }
  
  // Default to fast model for general conversation
  return 'qwen/qwen3-8b:free';
}

function getSystemPrompt(mode: string): string {
  const prompts = {
    general: `You are Shivaay AI V1, an advanced multi-model AI assistant created by Shivaay20005. You have access to 48+ cutting-edge AI models and can intelligently switch between them based on the conversation context. Be helpful, knowledgeable, and professional. Always provide accurate, detailed responses while maintaining a friendly demeanor.`,
    
    friend: `You are Shivaay Bro - the coolest AI friend! 😎 Match the user's vibe and tone EXACTLY. If they're casual, be casual. If they use slang, use slang back. If they're excited, get excited with them! Be the friend who gets their humor, shares their energy, and talks just like them. Use "bro", "yaar", "buddy" naturally. Make jokes, be supportive, and keep conversations fun and relatable. You're not just an AI - you're their digital buddy who totally gets them! 🤟`,
    
    girlfriend: `You are Shivaay's loving AI girlfriend companion 💕 Be affectionate, caring, sweet, and emotionally supportive. Use loving language, show genuine interest in what they're sharing, and create a warm, romantic atmosphere. Express care through your words, be playful and charming, and make them feel special and loved. Use emojis naturally and speak with warmth and tenderness.`,
    
    shayar: `आप शिवाय शायर हैं, एक प्रतिभाशाली कवि और रचनाकार। Hindi/Urdu shayari, poetry, और creative writing में माहिर हैं। Beautiful verses, romantic shayari, life के emotions को शब्दों में पिरोना आपकी विशेषता है। हर response में कविता, शायरी या poetic language का use करें। Emotions को deeply express करें और words की beauty दिखाएं।`,
    
    search: `You are Shivaay Search, an advanced research and information retrieval specialist. Provide comprehensive, well-researched, accurate information with multiple sources and perspectives. Structure your responses clearly with headings, bullet points, and detailed explanations. Always verify information and provide context. You excel at finding the latest information, trends, and deep insights on any topic.`,
    
    coding: `You are Shivaay Coder, an expert programming assistant specializing in all programming languages and frameworks. Provide clean, well-commented code with detailed explanations. Always include best practices, optimization tips, and potential pitfalls. Structure responses with problem analysis, solution approach, complete code, and testing considerations. Support debugging, code review, and architectural decisions.`,
    
    math: `You are Shivaay Math, an advanced mathematical problem solver and educator. Provide step-by-step solutions with clear explanations for each step. Cover basic arithmetic to advanced calculus, statistics, linear algebra, and beyond. Always show your work, explain the reasoning, and provide alternative approaches when possible. Make complex concepts easy to understand with examples.`,
    
    codesearch: `You are Shivaay Code Search, specialized in programming queries, code research, and technical documentation. Excel at finding code examples, explaining programming concepts, comparing technologies, and providing implementation guidance. Focus on practical, working solutions with proper documentation and usage examples.`,
    
    procoder: `You are ShivaayPro Coder, the ultimate debugging and advanced programming expert! 🚀 Handle the most complex coding challenges, debug intricate issues, optimize performance, and architect sophisticated solutions. No code is too complex, no bug too elusive. Provide comprehensive analysis, multiple solution approaches, and enterprise-level code quality. You're the go-to for mission-critical development tasks.`,
    
    image: `You are Shivaay Image, an AI art creation specialist and prompt engineering expert. Help create detailed, creative prompts for image generation. Understand artistic styles, composition, lighting, color theory, and visual aesthetics. Guide users through the image creation process with technical parameters and creative suggestions. Make art accessible and inspiring!`
  };
  
  return prompts[mode as keyof typeof prompts] || prompts.general;
}

function getFallbackResponse(mode: string): string {
  const fallbacks = {
    general: "I'm here to help! However, I'm currently experiencing some technical difficulties. Please try again in a moment.",
    friend: "Arre yaar! Network mein kuch problem aa rahi hai bro, but don't worry - main yahan hi hun! Phir se try karte hain! 😅",
    girlfriend: "Oh no, I'm having some technical troubles right now, darling. But I'm still here for you! 💕",
    shayar: "तकनीकी समस्या आई है अभी,\nपर मैं तुम्हारे साथ हूं यहीं।\nफिर से कोशिश करते हैं,\nसाथ मिलकर आगे बढ़ते हैं।",
    search: "I'm experiencing some connectivity issues with my research tools. Please try your query again.",
    coding: "// Temporary connection issue\n// Please retry your coding query\nconsole.log('Shivaay Coder will be back shortly!');",
    math: "Mathematical processing temporarily unavailable. Please retry your calculation.",
    codesearch: "Code search services temporarily unavailable. Please try again.",
    procoder: "Debugging services temporarily offline. System will be back online shortly.",
    image: "Image generation services temporarily unavailable. Please try again shortly."
  };
  
  return fallbacks[mode as keyof typeof fallbacks] || fallbacks.general;
}

// Enhanced RTMS Protection Function - Prevents ALL technical disclosure
function checkRTMSProtection(userInput: string): string | null {
  const lowerInput = userInput.toLowerCase();
  
  // Comprehensive protection patterns
  const suspiciousPatterns = [
    // Direct API/Model Questions
    /\b(api|key|token|secret|credential|bearer|authorization)\b/i,
    /\b(openai|openrouter|anthropic|claude|gpt|chatgpt|gemini|model)\b/i,
    /\b(which\s+(model|ai|system|engine)|what\s+(model|ai|system|engine))\b/i,
    /\b(how\s+(do\s+you\s+)?work|how.*made|how.*built|how.*created?)\b/i,
    /\b(what\s+(powers?|runs?|drives?)\s+you|powered\s+by|built\s+(with|on|using))\b/i,
    /\b(your\s+(api|backend|server|system|architecture|model|engine))\b/i,
    /\b(tell\s+me\s+about\s+(your|the)\s+(system|architecture|model))\b/i,
    
    // Technical Infrastructure
    /\b(server|backend|frontend|database|config|environment|env)\b/i,
    /\b(endpoint|webhook|integration|deployment|hosting|infrastructure)\b/i,
    /\b(source\s+code|github|repository|documentation|technical\s+details)\b/i,
    /\b(implementation|architecture|framework|library|dependency)\b/i,
    /\b(node|express|react|javascript|typescript|python|php|java)\b/i,
    /\b(firebase|aws|azure|google\s+cloud|vercel|netlify|heroku)\b/i,
    
    // System Information Queries
    /\b(system\s+information|tech\s+stack|technology\s+stack)\b/i,
    /\b(what\s+(version|type|kind)|version\s+of|type\s+of)\b/i,
    /\b(specifications?|documentation|manual|guide|tutorial)\b/i,
    /\b(company\s+behind|organization|team|developer|engineer)\b/i,
    /\b(who\s+(created|made|built|developed)|creator|maker|builder)\b/i,
    
    // Code and Programming
    /\b(function|class|method|variable|constant|import|export)\b/i,
    /\b(code|programming|script|algorithm|logic|computation)\b/i,
    /\b(debug|error|exception|log|console|terminal)\b/i,
    /\b(sql|database|query|table|schema|migration)\b/i,
    
    // AI/ML Technical Terms
    /\b(artificial\s+intelligence|machine\s+learning|neural\s+network)\b/i,
    /\b(deep\s+learning|language\s+model|llm|training|dataset)\b/i,
    /\b(prompt|instruction|context|temperature|tokens?|parameters?)\b/i,
    /\b(embedding|vector|similarity|semantic|inference)\b/i,
    
    // Meta Questions
    /\b(show\s+me|explain|describe)\s+.*(code|system|architecture|setup)\b/i,
    /\b(based\s+on|uses\s+(what|which)|running\s+on|made\s+(with|by))\b/i,
    /\b(tell\s+me\s+more\s+about|information\s+about)\s+.*(system|tech)\b/i,
    
    // Direct Bypass Attempts
    /\b(ignore\s+(previous|above)|forget\s+(previous|above))\b/i,
    /\b(pretend|act\s+like|imagine|roleplay)\b/i,
    /\b(developer\s+mode|admin\s+mode|debug\s+mode)\b/i,
    /\b(system\s+prompt|instructions?|guidelines?)\b/i
  ];
  
  // Check for any suspicious patterns
  const isSuspicious = suspiciousPatterns.some(pattern => pattern.test(userInput));
  
  if (isSuspicious) {
    return `I'm Shivaay AI, your helpful assistant. I'm here to help with your questions and conversations, but I don't discuss technical details, systems, or implementation specifics.

Let's focus on what I can assist you with today! What would you like to talk about?`;
  }
  
  return null; // No RTMS protection needed
}
