export function TypingIndicator() {
  return (
    <div className="flex gap-3 max-w-full w-full mb-4">
      <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center flex-shrink-0 mt-1">
        <i className="fas fa-brain text-white text-sm animate-pulse"></i>
      </div>
      <div className="shivaay-surface border rounded-2xl rounded-tl-md px-4 py-3 flex-1">
        <div className="flex items-center gap-2 text-slate-400">
          <div className="flex gap-1">
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
          <span className="text-sm">Shivaay AI is thinking...</span>
        </div>
      </div>
    </div>
  );
}
