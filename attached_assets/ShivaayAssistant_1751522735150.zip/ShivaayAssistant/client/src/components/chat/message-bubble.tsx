import { useState, useEffect } from "react";
import { type Message } from "@shared/schema";

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const [modelDisplaySettings, setModelDisplaySettings] = useState({
    showModelName: true,
    customModelDisplay: "",
    useCustomDisplay: false
  });

  // Load model display settings from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('shivaay_model_display');
    if (saved) {
      try {
        setModelDisplaySettings(JSON.parse(saved));
      } catch (e) {
        // Use defaults if parsing fails
      }
    }
  }, []);
  
  // Add safety checks
  if (!message || !message.content) {
    return null;
  }
  
  const isUser = message.role === 'user';

  // Function to copy text to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Function to render content with code blocks
  const renderContent = (content: string) => {
    const codeBlockRegex = /```(\w*)\n?([\s\S]*?)```/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      // Add text before code block
      if (match.index > lastIndex) {
        parts.push(
          <span key={lastIndex} className="whitespace-pre-wrap">
            {content.slice(lastIndex, match.index)}
          </span>
        );
      }

      // Add code block
      const language = match[1] || 'text';
      const code = match[2].trim();
      parts.push(
        <div key={match.index} className="my-3 rounded-lg bg-slate-900 border border-slate-700">
          <div className="flex items-center justify-between px-4 py-2 border-b border-slate-700 bg-slate-800 rounded-t-lg">
            <span className="text-xs text-slate-400 font-mono">{language}</span>
            <button
              onClick={() => copyToClipboard(code)}
              className="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1"
            >
              {copied ? (
                <>
                  <i className="fas fa-check"></i>
                  Copied!
                </>
              ) : (
                <>
                  <i className="fas fa-copy"></i>
                  Copy
                </>
              )}
            </button>
          </div>
          <pre className="p-4 text-sm text-slate-100 overflow-x-auto">
            <code>{code}</code>
          </pre>
        </div>
      );

      lastIndex = match.index + match[0].length;
    }

    // Add remaining text
    if (lastIndex < content.length) {
      parts.push(
        <span key={lastIndex} className="whitespace-pre-wrap">
          {content.slice(lastIndex)}
        </span>
      );
    }

    return parts.length > 0 ? parts : <span className="whitespace-pre-wrap">{content}</span>;
  };
  
  return (
    <div className={`chat-message flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      {isUser ? (
        <div className="message-bubble bg-primary rounded-2xl rounded-br-md px-4 py-3 text-white max-w-[80%] md:max-w-[70%]">
          <p className="whitespace-pre-wrap break-words">{message.content}</p>
        </div>
      ) : (
        <div className="flex gap-3 max-w-full w-full">
          <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center flex-shrink-0 mt-1">
            <i className="fas fa-brain text-white text-sm"></i>
          </div>
          <div className="message-bubble shivaay-surface border rounded-2xl rounded-tl-md px-4 py-3 flex-1 min-w-0">
            <div className="text-slate-100 break-words">
              {renderContent(message.content)}
            </div>
            <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-700">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                {modelDisplaySettings.showModelName && (
                  <>
                    <span>
                      Model: {
                        modelDisplaySettings.useCustomDisplay && modelDisplaySettings.customModelDisplay
                          ? modelDisplaySettings.customModelDisplay
                          : (message.metadata as any)?.model || 'Auto-Selected'
                      }
                    </span>
                    <span>•</span>
                  </>
                )}
                <span>Tokens: {(message.metadata as any)?.tokens || Math.floor((message.content || '').length / 4)}</span>
              </div>
              <button
                onClick={() => copyToClipboard(message.content)}
                className="text-xs text-slate-400 hover:text-white transition-colors flex items-center gap-1"
              >
                {copied ? (
                  <>
                    <i className="fas fa-check"></i>
                    Copied!
                  </>
                ) : (
                  <>
                    <i className="fas fa-copy"></i>
                    Copy
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
