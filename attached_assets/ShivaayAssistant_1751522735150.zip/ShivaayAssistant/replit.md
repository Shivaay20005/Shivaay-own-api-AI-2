# replit.md

## Overview

This is a modern full-stack AI assistant application called "Shivaay AI" built with a React frontend and Express backend. The application provides multiple conversation modes and AI integrations with features like chat interfaces, image generation, and an "engineer mode" for advanced functionality.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Bundler**: Vite for development and build processes
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Real-time Communication**: WebSocket integration for live chat

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Real-time**: WebSocket server for chat functionality
- **Build System**: ESBuild for production builds
- **Development**: TSX for TypeScript execution

### Database Architecture
- **Database**: PostgreSQL (active and configured via Drizzle)
- **Storage Layer**: DatabaseStorage class using Drizzle ORM
- **Schema Location**: `shared/schema.ts`
- **Migration System**: Drizzle Kit for schema management
- **Tables**: Users, conversations, messages, and generated images
- **Connection**: Neon serverless PostgreSQL with WebSocket support

## Key Components

### Data Models
- **Users**: Authentication and user management
- **Conversations**: Chat sessions with different modes (general, friend, girlfriend, shayar, search, coding, math, codesearch, procoder, image)
- **Messages**: Individual chat messages with role-based content
- **Generated Images**: AI-generated image storage with parameters

### Chat System
- Multiple conversation modes with specialized AI behaviors
- Real-time messaging via WebSocket
- Message persistence and conversation history
- Typing indicators and message metadata

### Authentication & Authorization
- Engineer mode with password protection ("Shivaay20005") 
- Basic user management system
- Session-based authentication preparation
- RTMS Protection against API disclosure attempts

### Model Display Features (Engineer Mode)
- Toggle to show/hide model names in chat bubbles
- Custom model display name option
- Real-time preview of display settings
- localStorage persistence of user preferences

### AI Integration
- Multiple AI model support through configuration
- Model selection and switching capabilities
- Token tracking and usage monitoring
- Support for different AI providers

### UI/UX Features
- Dark theme with custom Shivaay AI branding
- Responsive sidebar with mode selection
- Mobile-first responsive design
- Toast notifications and modal dialogs
- Custom gradient backgrounds and animations

## Data Flow

1. **User Authentication**: Password verification for engineer mode access
2. **Conversation Creation**: Users select modes and create new conversations
3. **Message Flow**: Messages sent via WebSocket, processed by AI, and stored in database
4. **Real-time Updates**: WebSocket broadcasts for live chat experience
5. **Image Generation**: Separate flow for AI image creation with parameter control

## External Dependencies

### Core Libraries
- **Database**: @neondatabase/serverless, drizzle-orm
- **UI Framework**: React, @radix-ui components
- **Styling**: tailwindcss, class-variance-authority
- **State Management**: @tanstack/react-query
- **Real-time**: ws (WebSocket)
- **Forms**: react-hook-form, @hookform/resolvers
- **Date Handling**: date-fns

### Development Tools
- **Build**: vite, esbuild, tsx
- **Database**: drizzle-kit
- **Linting**: TypeScript compiler
- **Replit Integration**: @replit/vite-plugin-runtime-error-modal

## Deployment Strategy

### Development Mode
- Vite dev server for frontend hot reloading
- TSX for backend TypeScript execution
- WebSocket server integrated with Express
- Database schema push via Drizzle Kit

### Production Build
- Vite builds optimized React bundle to `dist/public`
- ESBuild bundles Express server to `dist/index.js`
- Single Node.js process serves both static files and API
- Environment-based configuration via DATABASE_URL

### Database Management
- Drizzle migrations stored in `./migrations`
- Schema definitions in `shared/schema.ts`
- PostgreSQL connection via environment variables
- Auto-generated Zod schemas for validation

## Changelog

```
Changelog:
- June 30, 2025. Initial setup with React frontend and Express backend
- June 30, 2025. Added PostgreSQL database with Drizzle ORM
- June 30, 2025. Implemented 48+ OpenRouter AI models integration
- June 30, 2025. Added Engineer Mode with password protection
- June 30, 2025. Completed conversation modes (Friend, Girlfriend, Shayar, etc.)
- June 30, 2025. Added image generation and WebSocket real-time chat
- June 30, 2025. Added Chat History feature in Engineer Mode (ChatGPT-like)
- June 30, 2025. Added Model Name display customization controls in Engineer Mode
- June 30, 2025. Enhanced Friend Mode with tone matching and casual conversation style
- June 30, 2025. Implemented RTMS Protection to prevent API disclosure
- June 30, 2025. Added Model Display toggle (Show/Hide) and Custom Display Name options
- June 30, 2025. Implemented Firebase Authentication (Email/Password + Google OAuth)
- June 30, 2025. Added complete user registration and login system
- June 30, 2025. Enhanced RTMS Protection with comprehensive security patterns
- June 30, 2025. Implemented user-specific chat history and conversation management
- June 30, 2025. Added VS Code development and production deployment guides
- June 30, 2025. Completed authentication context provider and UI components
- June 30, 2025. Enhanced database schema with Firebase user integration
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```