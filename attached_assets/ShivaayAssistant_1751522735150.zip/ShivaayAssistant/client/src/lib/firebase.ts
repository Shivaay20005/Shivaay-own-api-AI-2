import { initializeApp } from "firebase/app";
import { getAuth, signInWithRedirect, signInWithPopup, GoogleAuthProvider, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, User } from "firebase/auth";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "demo-api-key",
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || "demo-project"}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "demo-project",
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || "demo-project"}.firebasestorage.app`,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:123456789:web:abcdef",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Google Auth Provider
const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('email');
googleProvider.addScope('profile');

export const FirebaseAuth = {
  // Sign up with email and password
  async signUpWithEmail(email: string, password: string, displayName?: string) {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      
      // Sync user to our database
      await this.syncUserToDatabase(userCredential.user, displayName);
      
      return userCredential.user;
    } catch (error: any) {
      throw new Error(error.message || 'Failed to create account');
    }
  },

  // Sign in with email and password
  async signInWithEmail(email: string, password: string) {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      
      // Update last login
      await this.updateLastLogin(userCredential.user);
      
      return userCredential.user;
    } catch (error: any) {
      throw new Error(error.message || 'Failed to sign in');
    }
  },

  // Sign in with Google
  async signInWithGoogle() {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      
      // Sync user to our database
      await this.syncUserToDatabase(result.user);
      
      return result.user;
    } catch (error: any) {
      throw new Error(error.message || 'Failed to sign in with Google');
    }
  },

  // Sign out
  async signOut() {
    try {
      await signOut(auth);
    } catch (error: any) {
      throw new Error(error.message || 'Failed to sign out');
    }
  },

  // Sync Firebase user to our database
  async syncUserToDatabase(firebaseUser: User, displayName?: string) {
    try {
      const userData = {
        firebaseUid: firebaseUser.uid,
        email: firebaseUser.email || '',
        displayName: displayName || firebaseUser.displayName || '',
        photoURL: firebaseUser.photoURL || '',
        username: firebaseUser.email?.split('@')[0] || `user_${Date.now()}`,
        provider: 'firebase'
      };

      const response = await fetch('/api/auth/sync-firebase-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      if (!response.ok) {
        throw new Error('Failed to sync user data');
      }

      return await response.json();
    } catch (error) {
      console.error('Error syncing user to database:', error);
      throw error;
    }
  },

  // Update last login
  async updateLastLogin(firebaseUser: User) {
    try {
      await fetch('/api/auth/update-last-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ firebaseUid: firebaseUser.uid }),
      });
    } catch (error) {
      console.error('Error updating last login:', error);
    }
  },

  // Get current user
  getCurrentUser() {
    return auth.currentUser;
  },

  // Listen to auth state changes
  onAuthStateChanged(callback: (user: User | null) => void) {
    return onAuthStateChanged(auth, callback);
  }
};